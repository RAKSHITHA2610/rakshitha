import { Brain, Target, Zap, Map } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Brain,
    title: "AI-Powered Analysis",
    description: "Advanced algorithms analyze your interests, goals, and availability to create the perfect learning roadmap."
  },
  {
    icon: Target,
    title: "Goal-Oriented Paths",
    description: "Every skill path is designed to help you reach your specific career objectives efficiently."
  },
  {
    icon: Zap,
    title: "Quick & Easy",
    description: "Get your personalized roadmap in minutes with our simple questionnaire."
  },
  {
    icon: Map,
    title: "Step-by-Step Guidance",
    description: "Clear progression from beginner to advanced with recommended resources at each step."
  }
];

export const Features = () => {
  return (
    <section id="features" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Why Choose Skill Path Finder?
          </h2>
          <p className="text-xl text-muted-foreground">
            We focus on decision support, not just courses. Get clarity on what to learn next.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="border-2 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/70 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
