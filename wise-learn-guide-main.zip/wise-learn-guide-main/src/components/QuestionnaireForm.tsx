import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";

export const QuestionnaireForm = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    interests: "",
    careerGoal: "",
    timeCommitment: "",
    currentSkillLevel: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.interests || !formData.careerGoal || !formData.timeCommitment) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('generate-roadmap', {
        body: formData
      });

      if (error) throw error;

      // Navigate to roadmap page with the generated data
      navigate('/roadmap', { state: { roadmap: data.roadmap, userInfo: formData } });
      
      toast({
        title: "Success!",
        description: "Your personalized learning path has been generated"
      });
    } catch (error) {
      console.error('Error generating roadmap:', error);
      toast({
        title: "Error",
        description: "Failed to generate roadmap. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto animate-fade-in">
      <CardHeader>
        <CardTitle className="text-3xl">Tell Us About Yourself</CardTitle>
        <CardDescription className="text-lg">
          Help us understand your learning goals so we can create the perfect roadmap for you
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Name (Optional)</Label>
            <Input
              id="name"
              placeholder="Your name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="interests" className="required">What are you interested in learning? *</Label>
            <Textarea
              id="interests"
              placeholder="E.g., AI, Web Development, Data Science, Design..."
              className="min-h-24"
              value={formData.interests}
              onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="careerGoal" className="required">What's your career goal? *</Label>
            <Textarea
              id="careerGoal"
              placeholder="E.g., Become a Machine Learning Engineer, Start a tech company..."
              className="min-h-24"
              value={formData.careerGoal}
              onChange={(e) => setFormData({ ...formData, careerGoal: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="timeCommitment" className="required">How much time can you commit per week? *</Label>
            <Select 
              value={formData.timeCommitment}
              onValueChange={(value) => setFormData({ ...formData, timeCommitment: value })}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select time commitment" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1-3 hours">1-3 hours per week</SelectItem>
                <SelectItem value="4-6 hours">4-6 hours per week</SelectItem>
                <SelectItem value="7-10 hours">7-10 hours per week</SelectItem>
                <SelectItem value="10+ hours">10+ hours per week</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="currentSkillLevel">Current Skill Level (Optional)</Label>
            <Select 
              value={formData.currentSkillLevel}
              onValueChange={(value) => setFormData({ ...formData, currentSkillLevel: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select your current level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="complete-beginner">Complete Beginner</SelectItem>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button 
            type="submit" 
            className="w-full text-lg py-6"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Generating Your Roadmap...
              </>
            ) : (
              "Generate My Learning Path"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};
