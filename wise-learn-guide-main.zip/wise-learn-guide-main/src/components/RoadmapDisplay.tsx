import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Circle, ArrowRight } from "lucide-react";

interface RoadmapStep {
  title: string;
  description: string;
  duration: string;
  resources?: string[];
}

interface RoadmapDisplayProps {
  roadmap: {
    title: string;
    steps: RoadmapStep[];
  };
  userName?: string;
}

export const RoadmapDisplay = ({ roadmap, userName }: RoadmapDisplayProps) => {
  return (
    <div className="w-full max-w-4xl mx-auto space-y-8 animate-fade-in">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold">
          {userName ? `${userName}'s ` : "Your "}Learning Roadmap
        </h1>
        <p className="text-xl text-muted-foreground">{roadmap.title}</p>
      </div>

      <div className="relative space-y-6">
        {/* Connection line */}
        <div className="absolute left-6 top-8 bottom-8 w-0.5 bg-gradient-to-b from-primary via-primary/50 to-transparent hidden md:block" />

        {roadmap.steps.map((step, index) => (
          <Card 
            key={index} 
            className="relative hover:shadow-lg transition-all duration-300 hover:-translate-y-1 animate-fade-in"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <CardHeader>
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center relative z-10">
                  {index === 0 ? (
                    <CheckCircle2 className="w-6 h-6 text-primary-foreground" />
                  ) : (
                    <Circle className="w-6 h-6 text-primary-foreground" />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary">Step {index + 1}</Badge>
                    <Badge variant="outline">{step.duration}</Badge>
                  </div>
                  <CardTitle className="text-2xl">{step.title}</CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pl-20">
              <p className="text-muted-foreground mb-4">{step.description}</p>
              
              {step.resources && step.resources.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm flex items-center gap-2">
                    <ArrowRight className="w-4 h-4" />
                    Recommended Resources:
                  </h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                    {step.resources.map((resource, idx) => (
                      <li key={idx}>{resource}</li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20">
        <CardContent className="pt-6">
          <div className="text-center space-y-2">
            <h3 className="text-2xl font-bold">Ready to Start Your Journey?</h3>
            <p className="text-muted-foreground">
              Follow this roadmap step by step, and you'll achieve your learning goals in no time!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
