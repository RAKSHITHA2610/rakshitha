import { useLocation, useNavigate } from "react-router-dom";
import { RoadmapDisplay } from "@/components/RoadmapDisplay";
import { Button } from "@/components/ui/button";
import { ArrowLeft, RotateCcw } from "lucide-react";
import { useEffect } from "react";

const Roadmap = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { roadmap, userInfo } = location.state || {};

  useEffect(() => {
    if (!roadmap) {
      navigate('/questionnaire');
    }
  }, [roadmap, navigate]);

  if (!roadmap) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/20">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
          
          <Button
            variant="outline"
            onClick={() => navigate('/questionnaire')}
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Create New Roadmap
          </Button>
        </div>
        
        <RoadmapDisplay roadmap={roadmap} userName={userInfo?.name} />
      </div>
    </div>
  );
};

export default Roadmap;
