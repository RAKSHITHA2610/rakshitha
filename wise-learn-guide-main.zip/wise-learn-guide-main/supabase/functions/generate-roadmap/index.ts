// Edge function for generating personalized learning roadmaps

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { interests, careerGoal, timeCommitment, currentSkillLevel } = await req.json();
    
    console.log('Generating roadmap for:', { interests, careerGoal, timeCommitment, currentSkillLevel });

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    // Create a detailed prompt for the AI
    const systemPrompt = `You are an expert career advisor and learning path designer. Your role is to create personalized, actionable learning roadmaps that help people achieve their career goals efficiently.

When creating a roadmap:
1. Break down the learning path into 4-6 clear, progressive steps
2. Each step should build on the previous one
3. Include realistic time estimates for each step
4. Suggest 2-3 specific, high-quality learning resources for each step (courses, books, or platforms)
5. Make it practical and achievable given the user's time commitment
6. Start from their current skill level if provided

Return the response as a JSON object with this exact structure:
{
  "title": "A clear, motivating title for the roadmap",
  "steps": [
    {
      "title": "Step title",
      "description": "Detailed description of what to learn and why",
      "duration": "Time estimate (e.g., '2-3 weeks', '1 month')",
      "resources": ["Resource 1", "Resource 2", "Resource 3"]
    }
  ]
}`;

    const userPrompt = `Create a personalized learning roadmap for someone with these details:

Interests: ${interests}
Career Goal: ${careerGoal}
Time Commitment: ${timeCommitment}
Current Skill Level: ${currentSkillLevel || 'Not specified'}

Please create a detailed, step-by-step learning roadmap that will help them achieve their career goal efficiently.`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        response_format: { type: 'json_object' }
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI API error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again in a moment.' }), 
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Service temporarily unavailable. Please try again later.' }), 
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    const roadmapText = data.choices[0].message.content;
    
    console.log('Generated roadmap:', roadmapText);
    
    // Parse the JSON response
    const roadmap = JSON.parse(roadmapText);

    return new Response(
      JSON.stringify({ roadmap }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );
  } catch (error) {
    console.error('Error in generate-roadmap function:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'An unexpected error occurred' 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
